package com.hispanet.vigia;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.lang.ref.WeakReference;

/** Pantalla principal: muestra la interfaz (assets/index.html) y la conecta con la base de datos. */
public class MainActivity extends Activity {

    private static WeakReference<MainActivity> actual = new WeakReference<>(null);
    private WebView web;
    volatile long contactoInicial = -1;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Avisos.crearCanal(this);
        leerIntent(getIntent());

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        web.setBackgroundColor(0xFF0B141A);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Puente(this), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private void leerIntent(Intent i) {
        if (i != null && i.hasExtra("contacto")) {
            contactoInicial = i.getLongExtra("contacto", -1);
            i.removeExtra("contacto");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        leerIntent(intent);
        js("window.alAbrir&&alAbrir()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        actual = new WeakReference<>(this);
        js("window.alAbrir&&alAbrir()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        actual = new WeakReference<>(null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        js("window.alAbrir&&alAbrir()");
    }

    @Override
    public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("window.atras?atras():false", v -> {
                if (!"true".equals(v)) super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    void js(String code) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    /** Lo llaman el lector de notificaciones y el de SMS al guardar un mensaje nuevo. */
    public static void refrescar() {
        new Handler(Looper.getMainLooper()).post(() -> {
            MainActivity a = actual.get();
            if (a != null) a.js("window.onDatos&&onDatos()");
        });
    }
}
