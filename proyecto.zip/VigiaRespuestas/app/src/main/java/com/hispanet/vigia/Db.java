package com.hispanet.vigia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Base de datos local: números vigilados, mensajes recibidos y ajustes. */
public class Db extends SQLiteOpenHelper {

    private static Db inst;

    public static synchronized Db get(Context c) {
        if (inst == null) inst = new Db(c.getApplicationContext());
        return inst;
    }

    private Db(Context c) {
        super(c, "vigia.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE contactos(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, numero TEXT, clave TEXT UNIQUE, " +
                "nota TEXT, activo INTEGER DEFAULT 1, creado INTEGER)");
        db.execSQL("CREATE TABLE mensajes(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, contacto_id INTEGER, via TEXT, texto TEXT, " +
                "ts INTEGER, atendido INTEGER DEFAULT 0)");
        db.execSQL("CREATE INDEX ix_m_ts ON mensajes(ts)");
        db.execSQL("CREATE INDEX ix_m_c ON mensajes(contacto_id)");
        db.execSQL("CREATE TABLE ajustes(k TEXT PRIMARY KEY, v TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { }

    public static class Contacto {
        public long id;
        public String nombre;
        public String numero;
        public boolean activo;
    }

    // ---------------- ajustes ----------------

    public String ajuste(String k, String def) {
        Cursor cu = getReadableDatabase().rawQuery("SELECT v FROM ajustes WHERE k=?", new String[]{k});
        try {
            return cu.moveToFirst() ? cu.getString(0) : def;
        } finally {
            cu.close();
        }
    }

    public void guardarAjuste(String k, String v) {
        ContentValues cv = new ContentValues();
        cv.put("k", k);
        cv.put("v", v);
        getWritableDatabase().insertWithOnConflict("ajustes", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String pais() {
        return ajuste("pais", "53");
    }

    // ---------------- contactos ----------------

    private boolean existeClave(String clave, long exceptoId) {
        Cursor cu = getReadableDatabase().rawQuery(
                "SELECT 1 FROM contactos WHERE clave=? AND id<>? LIMIT 1",
                new String[]{clave, String.valueOf(exceptoId)});
        try {
            return cu.moveToFirst();
        } finally {
            cu.close();
        }
    }

    /** 1 = añadido, 0 = ya estaba, -1 = número no válido */
    public int agregarContacto(String nombre, String numero, String nota) {
        String clave = Numeros.clave(numero);
        if (clave.length() < 7) return -1;
        if (existeClave(clave, -1)) return 0;
        String norm = Numeros.normalizar(numero, pais());
        if (nombre == null || nombre.trim().isEmpty()) nombre = norm;
        ContentValues cv = new ContentValues();
        cv.put("nombre", nombre.trim());
        cv.put("numero", norm);
        cv.put("clave", clave);
        cv.put("nota", nota == null ? "" : nota.trim());
        cv.put("activo", 1);
        cv.put("creado", System.currentTimeMillis());
        return getWritableDatabase().insert("contactos", null, cv) == -1 ? 0 : 1;
    }

    /** "" si todo bien, o el motivo del error. */
    public String actualizarContacto(long id, String nombre, String numero, String nota, boolean activo) {
        String clave = Numeros.clave(numero);
        if (clave.length() < 7) return "Número no válido";
        if (existeClave(clave, id)) return "Ese número ya está en la lista";
        String norm = Numeros.normalizar(numero, pais());
        ContentValues cv = new ContentValues();
        cv.put("nombre", (nombre == null || nombre.trim().isEmpty()) ? norm : nombre.trim());
        cv.put("numero", norm);
        cv.put("clave", clave);
        cv.put("nota", nota == null ? "" : nota.trim());
        cv.put("activo", activo ? 1 : 0);
        getWritableDatabase().update("contactos", cv, "id=?", new String[]{String.valueOf(id)});
        return "";
    }

    public void borrarContacto(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("mensajes", "contacto_id=?", new String[]{String.valueOf(id)});
        db.delete("contactos", "id=?", new String[]{String.valueOf(id)});
    }

    private Contacto leer(Cursor cu) {
        Contacto c = new Contacto();
        c.id = cu.getLong(0);
        c.nombre = cu.getString(1);
        c.numero = cu.getString(2);
        c.activo = cu.getInt(3) == 1;
        return c;
    }

    private Contacto uno(String sql, String[] args) {
        Cursor cu = getReadableDatabase().rawQuery(sql, args);
        try {
            return cu.moveToFirst() ? leer(cu) : null;
        } finally {
            cu.close();
        }
    }

    /** Busca un número ACTIVO de la lista. null si no está vigilado. */
    public Contacto buscarPorNumero(String raw) {
        String clave = Numeros.clave(raw);
        if (clave.length() < 7) return null;
        return uno("SELECT id,nombre,numero,activo FROM contactos WHERE activo=1 AND clave=? LIMIT 1",
                new String[]{clave});
    }

    public Contacto buscarPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) return null;
        return uno("SELECT id,nombre,numero,activo FROM contactos WHERE activo=1 AND nombre=? COLLATE NOCASE LIMIT 1",
                new String[]{nombre.trim()});
    }

    public Contacto porId(long id) {
        return uno("SELECT id,nombre,numero,activo FROM contactos WHERE id=?", new String[]{String.valueOf(id)});
    }

    // ---------------- mensajes ----------------

    /** Guarda el mensaje si no es repetido. true = era nuevo. */
    public synchronized boolean guardarMensaje(long contactoId, String via, String texto, long ts) {
        if (texto == null) texto = "";
        texto = texto.trim();
        if (texto.isEmpty()) return false;
        Cursor cu = getReadableDatabase().rawQuery(
                "SELECT 1 FROM mensajes WHERE contacto_id=? AND via=? AND texto=? AND ts>? AND ts<? LIMIT 1",
                new String[]{String.valueOf(contactoId), via, texto,
                        String.valueOf(ts - 600000L), String.valueOf(ts + 600000L)});
        try {
            if (cu.moveToFirst()) return false; // repetido (misma persona, mismo texto, menos de 10 min)
        } finally {
            cu.close();
        }
        ContentValues cv = new ContentValues();
        cv.put("contacto_id", contactoId);
        cv.put("via", via);
        cv.put("texto", texto);
        cv.put("ts", ts);
        cv.put("atendido", 0);
        return getWritableDatabase().insert("mensajes", null, cv) != -1;
    }

    public void marcarAtendido(long contactoId) {
        ContentValues cv = new ContentValues();
        cv.put("atendido", 1);
        getWritableDatabase().update("mensajes", cv, "contacto_id=? AND atendido=0",
                new String[]{String.valueOf(contactoId)});
    }

    public void atenderTodos() {
        ContentValues cv = new ContentValues();
        cv.put("atendido", 1);
        getWritableDatabase().update("mensajes", cv, "atendido=0", null);
    }

    public void borrarMensaje(long id) {
        getWritableDatabase().delete("mensajes", "id=?", new String[]{String.valueOf(id)});
    }

    // ---------------- JSON para la pantalla ----------------

    public String contactosJson() {
        JSONArray arr = new JSONArray();
        Cursor cu = getReadableDatabase().rawQuery(
                "SELECT c.id,c.nombre,c.numero,c.activo,c.nota,c.creado," +
                        "(SELECT COUNT(*) FROM mensajes m WHERE m.contacto_id=c.id)," +
                        "(SELECT MAX(ts) FROM mensajes m WHERE m.contacto_id=c.id)," +
                        "(SELECT COUNT(*) FROM mensajes m WHERE m.contacto_id=c.id AND m.atendido=0) " +
                        "FROM contactos c ORDER BY 8 DESC, c.creado DESC", null);
        try {
            while (cu.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", cu.getLong(0));
                o.put("nombre", cu.getString(1));
                o.put("numero", cu.getString(2));
                o.put("activo", cu.getInt(3) == 1);
                o.put("nota", cu.isNull(4) ? "" : cu.getString(4));
                o.put("creado", cu.getLong(5));
                o.put("total", cu.getInt(6));
                o.put("ultimo", cu.isNull(7) ? 0 : cu.getLong(7));
                o.put("pendientes", cu.getInt(8));
                arr.put(o);
            }
        } catch (JSONException ignored) {
        } finally {
            cu.close();
        }
        return arr.toString();
    }

    public String mensajesJson(long desde, long hasta, long contactoId) {
        JSONArray arr = new JSONArray();
        String sql = "SELECT m.id,m.contacto_id,c.nombre,c.numero,m.via,m.texto,m.ts,m.atendido " +
                "FROM mensajes m JOIN contactos c ON c.id=m.contacto_id WHERE m.ts>=? AND m.ts<?" +
                (contactoId > 0 ? " AND m.contacto_id=?" : "") + " ORDER BY m.ts DESC LIMIT 5000";
        String[] args = contactoId > 0
                ? new String[]{String.valueOf(desde), String.valueOf(hasta), String.valueOf(contactoId)}
                : new String[]{String.valueOf(desde), String.valueOf(hasta)};
        Cursor cu = getReadableDatabase().rawQuery(sql, args);
        try {
            while (cu.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", cu.getLong(0));
                o.put("cid", cu.getLong(1));
                o.put("nombre", cu.getString(2));
                o.put("numero", cu.getString(3));
                o.put("via", cu.getString(4));
                o.put("texto", cu.getString(5));
                o.put("ts", cu.getLong(6));
                o.put("atendido", cu.getInt(7) == 1);
                arr.put(o);
            }
        } catch (JSONException ignored) {
        } finally {
            cu.close();
        }
        return arr.toString();
    }

    public String pendientesJson() {
        JSONArray arr = new JSONArray();
        Cursor cu = getReadableDatabase().rawQuery(
                "SELECT c.id,c.nombre,c.numero,COUNT(*),MAX(m.ts)," +
                        "(SELECT x.texto FROM mensajes x WHERE x.contacto_id=c.id AND x.atendido=0 ORDER BY x.ts DESC LIMIT 1)," +
                        "(SELECT x.via FROM mensajes x WHERE x.contacto_id=c.id AND x.atendido=0 ORDER BY x.ts DESC LIMIT 1) " +
                        "FROM mensajes m JOIN contactos c ON c.id=m.contacto_id WHERE m.atendido=0 " +
                        "GROUP BY c.id ORDER BY MAX(m.ts) DESC", null);
        try {
            while (cu.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", cu.getLong(0));
                o.put("nombre", cu.getString(1));
                o.put("numero", cu.getString(2));
                o.put("cuantos", cu.getInt(3));
                o.put("ts", cu.getLong(4));
                o.put("texto", cu.getString(5));
                o.put("via", cu.getString(6));
                arr.put(o);
            }
        } catch (JSONException ignored) {
        } finally {
            cu.close();
        }
        return arr.toString();
    }
}
