package com.hispanet.vigia;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;

/** Pantalla principal: muestra la interfaz (assets/index.html) y la conecta con la base de datos. */
public class MainActivity extends Activity {

    private static WeakReference<MainActivity> actual = new WeakReference<>(null);
    private WebView web;
    volatile long contactoInicial = -1;
    /** Texto recibido con "Compartir" desde otra app (lista de números). */
    volatile String textoCompartido = null;
    private ValueCallback<Uri[]> elegirArchivo;
    private static final int PEDIR_ARCHIVO = 41;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Avisos.crearCanal(this);
        leerIntent(getIntent());

        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        web.setBackgroundColor(0xFF0B141A);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (elegirArchivo != null) elegirArchivo.onReceiveValue(null);
                elegirArchivo = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Elige la lista de números"), PEDIR_ARCHIVO);
                } catch (Exception e) {
                    elegirArchivo = null;
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Puente(this), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private void leerIntent(Intent i) {
        if (i == null) return;
        if (i.hasExtra("contacto")) {
            contactoInicial = i.getLongExtra("contacto", -1);
            i.removeExtra("contacto");
        }
        if (Intent.ACTION_SEND.equals(i.getAction())) {
            String t = null;
            CharSequence cs = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (cs != null) t = cs.toString();
            Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) {
                String f = leerUri(u);
                if (f != null) t = (t == null ? "" : t + "\n") + f;
            }
            if (t != null && !t.trim().isEmpty()) textoCompartido = t;
            i.setAction(Intent.ACTION_MAIN);
        }
    }

    private String leerUri(Uri u) {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            if (in == null) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0 && total < 5_000_000) {
                out.write(buf, 0, n);
                total += n;
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PEDIR_ARCHIVO && elegirArchivo != null) {
            elegirArchivo.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            elegirArchivo = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        leerIntent(intent);
        js("window.alAbrir&&alAbrir()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        actual = new WeakReference<>(this);
        js("window.alAbrir&&alAbrir()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        actual = new WeakReference<>(null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        js("window.alAbrir&&alAbrir()");
    }

    @Override
    public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("window.atras?atras():false", v -> {
                if (!"true".equals(v)) super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    void js(String code) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    /** Lo llaman el lector de notificaciones y el de SMS al guardar un mensaje nuevo. */
    public static void refrescar() {
        new Handler(Looper.getMainLooper()).post(() -> {
            MainActivity a = actual.get();
            if (a != null) a.js("window.onDatos&&onDatos()");
        });
    }
}
