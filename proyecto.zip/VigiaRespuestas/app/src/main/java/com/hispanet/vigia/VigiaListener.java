package com.hispanet.vigia;

import android.Manifest;
import android.app.Notification;
import android.app.Person;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Lee las notificaciones de WhatsApp. Solo registra los mensajes de chats
 * individuales que vienen de un número de la lista. Ignora grupos, llamadas,
 * resúmenes y los mensajes propios.
 */
public class VigiaListener extends NotificationListenerService {

    private static boolean esWhatsApp(String pkg) {
        return "com.whatsapp".equals(pkg) || "com.whatsapp.w4b".equals(pkg);
    }

    @Override
    public void onListenerConnected() {
        Db.get(this).guardarAjuste("listener_conectado", String.valueOf(System.currentTimeMillis()));
    }

    @Override
    public void onListenerDisconnected() {
        if (Build.VERSION.SDK_INT >= 24) {
            NotificationListenerService.requestRebind(new ComponentName(this, VigiaListener.class));
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            procesar(sbn);
        } catch (Throwable t) {
            Db.get(this).guardarAjuste("ultimo_error", String.valueOf(t));
        }
    }

    private static String txt(CharSequence cs) {
        return cs == null ? "" : cs.toString().trim();
    }

    private void procesar(StatusBarNotification sbn) {
        if (sbn == null || !esWhatsApp(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null) return;
        Db db = Db.get(this);
        db.guardarAjuste("ultima_wa", String.valueOf(System.currentTimeMillis()));

        // Resúmenes ("5 mensajes de 3 chats") y llamadas: fuera
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if (Notification.CATEGORY_CALL.equals(n.category) || "missed_call".equals(n.category)) return;

        Bundle ex = n.extras;
        if (ex == null) return;

        // Grupos: fuera
        if (ex.getBoolean("android.isGroupConversation", false)) return;
        String titulo = txt(ex.getCharSequence(Notification.EXTRA_TITLE));
        String conv = txt(ex.getCharSequence("android.conversationTitle"));
        if (titulo.isEmpty()) return;
        if (!conv.isEmpty() && !conv.equals(titulo)) return;
        if (titulo.contains(" @ ")) return;

        String tl = titulo.toLowerCase(Locale.ROOT);
        if (tl.equals("whatsapp") || tl.equals("whatsapp business")) return;

        // "Juan (3 mensajes)" -> "Juan"
        titulo = titulo.replaceAll("\\s*\\(\\d+[^)]*\\)\\s*$", "").trim();

        Db.Contacto c = identificar(titulo, ex, db);
        if (c == null) return; // no es de mi lista

        int nuevos = 0;
        String ultimo = null;
        boolean usado = false;

        Parcelable[] arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (arr != null) {
            for (Parcelable p : arr) {
                if (!(p instanceof Bundle)) continue;
                Bundle b = (Bundle) p;
                CharSequence t = b.getCharSequence("text");
                if (t == null) continue;
                // Mensaje propio: no tiene remitente
                boolean propio = b.getCharSequence("sender") == null && b.get("sender_person") == null;
                if (propio) continue;
                usado = true;
                long ts = b.getLong("time", sbn.getPostTime());
                if (db.guardarMensaje(c.id, "WhatsApp", t.toString(), ts)) {
                    nuevos++;
                    ultimo = t.toString();
                }
            }
        }

        if (!usado) {
            String t = txt(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));
            if (t.isEmpty()) t = txt(ex.getCharSequence(Notification.EXTRA_TEXT));
            if (t.isEmpty()) return;
            String tlow = t.toLowerCase(Locale.ROOT);
            if (tlow.contains("mensajes nuevos") || tlow.contains("new messages")) return;
            if (db.guardarMensaje(c.id, "WhatsApp", t, sbn.getPostTime())) {
                nuevos++;
                ultimo = t;
            }
        }

        if (nuevos > 0) {
            Avisos.avisar(this, c, "WhatsApp", ultimo, nuevos);
            MainActivity.refrescar();
        }
    }

    /** Averigua de qué contacto de la lista es la notificación. */
    private Db.Contacto identificar(String titulo, Bundle ex, Db db) {
        // 1) El título es el número (no está guardado en la agenda)
        if (Numeros.pareceNumero(titulo)) return db.buscarPorNumero(titulo);

        // 2) La notificación trae la persona con su número
        if (Build.VERSION.SDK_INT >= 28) {
            Db.Contacto c = porPersonas(ex, db);
            if (c != null) return c;
        }
        String[] gente = ex.getStringArray(Notification.EXTRA_PEOPLE);
        if (gente != null) {
            for (String u : gente) {
                Db.Contacto c = porUri(u, db);
                if (c != null) return c;
            }
        }

        // 3) Mismo nombre que pusiste en la lista
        Db.Contacto c = db.buscarPorNombre(titulo);
        if (c != null) return c;

        // 4) Buscar el nombre en la agenda del móvil y comparar sus números
        return porAgenda(titulo, db);
    }

    private Db.Contacto porPersonas(Bundle ex, Db db) {
        Object lista = ex.get("android.people.list");
        if (!(lista instanceof ArrayList)) return null;
        for (Object o : (ArrayList<?>) lista) {
            if (o instanceof Person) {
                Db.Contacto c = porUri(((Person) o).getUri(), db);
                if (c != null) return c;
            }
        }
        return null;
    }

    private boolean puedeLeerAgenda() {
        return checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    private Db.Contacto porUri(String u, Db db) {
        if (u == null || u.isEmpty()) return null;
        if (u.startsWith("tel:")) return db.buscarPorNumero(Uri.decode(u.substring(4)));
        if (u.startsWith("content://com.android.contacts") && puedeLeerAgenda()) {
            try (Cursor cu = getContentResolver().query(Uri.parse(u),
                    new String[]{ContactsContract.Contacts._ID}, null, null, null)) {
                if (cu != null && cu.moveToFirst()) {
                    return porIdAgenda(cu.getLong(0), db);
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private Db.Contacto porIdAgenda(long contactId, Db db) {
        try (Cursor cu = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                new String[]{String.valueOf(contactId)}, null)) {
            while (cu != null && cu.moveToNext()) {
                Db.Contacto c = db.buscarPorNumero(cu.getString(0));
                if (c != null) return c;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private Db.Contacto porAgenda(String nombre, Db db) {
        if (!puedeLeerAgenda()) return null;
        try (Cursor cu = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + "=?",
                new String[]{nombre}, null)) {
            while (cu != null && cu.moveToNext()) {
                Db.Contacto c = db.buscarPorNumero(cu.getString(0));
                if (c != null) return c;
            }
        } catch (Exception ignored) { }
        return null;
    }
}
