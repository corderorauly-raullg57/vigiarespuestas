package com.hispanet.vigia;

/** Utilidades para comparar números de teléfono sin importar el formato. */
public final class Numeros {
    private Numeros() {}

    public static String digitos(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') b.append(ch);
        }
        return b.toString();
    }

    /**
     * Clave de comparación: los últimos 8 dígitos.
     * Así "+53 5 5081288", "55081288" y "0053 55081288" son el mismo número.
     */
    public static String clave(String s) {
        String d = digitos(s);
        return d.length() > 8 ? d.substring(d.length() - 8) : d;
    }

    /** true si el texto es un número (sin letras) y no un nombre. */
    public static boolean pareceNumero(String s) {
        if (s == null) return false;
        if (digitos(s).length() < 7) return false;
        for (int i = 0; i < s.length(); i++) {
            if (Character.isLetter(s.charAt(i))) return false;
        }
        return true;
    }

    /** Devuelve el número en formato internacional: +53XXXXXXXX */
    public static String normalizar(String s, String pais) {
        String d = digitos(s);
        if (d.isEmpty()) return "";
        String t = s.trim();
        if (t.startsWith("+")) return "+" + d;
        if (d.startsWith("00")) return "+" + d.substring(2);
        if (d.length() <= 8) return "+" + digitos(pais) + d;
        return "+" + d;
    }

    /** Solo dígitos con código de país, para enlaces wa.me / sms. */
    public static String internacional(String numero, String pais) {
        return digitos(normalizar(numero, pais));
    }
}
