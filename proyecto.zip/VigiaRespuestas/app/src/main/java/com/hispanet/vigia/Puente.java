package com.hispanet.vigia;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Funciones que la pantalla (JavaScript) puede llamar como Android.xxx() */
public class Puente {

    private final MainActivity act;
    private final Db db;

    Puente(MainActivity a) {
        act = a;
        db = Db.get(a);
    }

    private boolean tiene(String perm) {
        return act.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean listenerActivo() {
        String s = Settings.Secure.getString(act.getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(act.getPackageName());
    }

    @JavascriptInterface
    public String estado() {
        JSONObject o = new JSONObject();
        try {
            o.put("listener", listenerActivo());
            o.put("sms", tiene(Manifest.permission.RECEIVE_SMS));
            o.put("agenda", tiene(Manifest.permission.READ_CONTACTS));
            o.put("notif", Build.VERSION.SDK_INT < 33 || tiene("android.permission.POST_NOTIFICATIONS"));
            PowerManager pm = (PowerManager) act.getSystemService(Context.POWER_SERVICE);
            o.put("bateria", pm != null && pm.isIgnoringBatteryOptimizations(act.getPackageName()));
            o.put("ultimaWa", Long.parseLong(db.ajuste("ultima_wa", "0")));
            o.put("error", db.ajuste("ultimo_error", ""));
            o.put("version", "1.2.1");
        } catch (Exception ignored) { }
        return o.toString();
    }

    @JavascriptInterface
    public void abrirAccesoNotificaciones() {
        abrir(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
    }

    @JavascriptInterface
    public void abrirBateria() {
        abrir(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    }

    @JavascriptInterface
    public void abrirAjustesApp() {
        abrir(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + act.getPackageName())));
    }

    @JavascriptInterface
    public void abrirSonidoAviso() {
        Avisos.crearCanal(act);
        if (Build.VERSION.SDK_INT >= 26) {
            Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, act.getPackageName())
                    .putExtra(Settings.EXTRA_CHANNEL_ID, Avisos.CANAL);
            abrir(i);
        } else {
            abrirAjustesApp();
        }
    }

    @JavascriptInterface
    public void pedirPermisos() {
        List<String> p = new ArrayList<>();
        if (!tiene(Manifest.permission.RECEIVE_SMS)) p.add(Manifest.permission.RECEIVE_SMS);
        if (!tiene(Manifest.permission.READ_CONTACTS)) p.add(Manifest.permission.READ_CONTACTS);
        if (Build.VERSION.SDK_INT >= 33 && !tiene("android.permission.POST_NOTIFICATIONS"))
            p.add("android.permission.POST_NOTIFICATIONS");
        if (Build.VERSION.SDK_INT < 29 && !tiene(Manifest.permission.WRITE_EXTERNAL_STORAGE))
            p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (p.isEmpty()) return;
        final String[] arr = p.toArray(new String[0]);
        act.runOnUiThread(() -> act.requestPermissions(arr, 7));
    }

    private void abrir(Intent i) {
        act.runOnUiThread(() -> {
            try {
                act.startActivity(i);
            } catch (Exception e) {
                abrirAjustesAppDirecto();
            }
        });
    }

    private void abrirAjustesAppDirecto() {
        try {
            act.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + act.getPackageName())));
        } catch (Exception ignored) { }
    }

    // ---------------- datos ----------------

    @JavascriptInterface public String contactos() { return db.contactosJson(); }

    @JavascriptInterface public String pendientes() { return db.pendientesJson(); }

    @JavascriptInterface
    public String mensajes(String desde, String hasta, String contactoId) {
        return db.mensajesJson(Long.parseLong(desde), Long.parseLong(hasta), Long.parseLong(contactoId));
    }

    @JavascriptInterface public void atendido(String id) { db.marcarAtendido(Long.parseLong(id)); }

    @JavascriptInterface public void atenderTodos() { db.atenderTodos(); }

    @JavascriptInterface public void borrarMensaje(String id) { db.borrarMensaje(Long.parseLong(id)); }

    @JavascriptInterface public void borrarContacto(String id) { db.borrarContacto(Long.parseLong(id)); }

    @JavascriptInterface
    public String guardarContacto(String id, String nombre, String numero, String nota, boolean activo) {
        long lid = Long.parseLong(id);
        if (lid <= 0) {
            int r = db.agregarContacto(nombre, numero, nota);
            return r == 1 ? "" : (r == 0 ? "Ese número ya está en la lista" : "Número no válido");
        }
        return db.actualizarContacto(lid, nombre, numero, nota, activo);
    }

    private static final Pattern NUM = Pattern.compile("\\+?\\d[\\d\\s().\\-]{5,}\\d");

    /**
     * Añade muchos números de golpe. Una línea por número.
     * Vale: "55081288", "+53 5 508 1288", "Juan Pérez, 55081288", "55081288 Juan".
     */
    @JavascriptInterface
    public String agregarLote(String texto) {
        int nuevos = 0, repetidos = 0, malos = 0;
        if (texto != null) {
            for (String linea : texto.split("\\r?\\n")) {
                String l = linea.trim();
                if (l.isEmpty()) continue;
                Matcher m = NUM.matcher(l);
                if (!m.find()) { malos++; continue; }
                String numero = m.group();
                String nombre = (l.substring(0, m.start()) + " " + l.substring(m.end()))
                        .replaceAll("[,;:|\\t]+", " ").replaceAll("\\s+", " ").trim();
                if (nombre.startsWith("-")) nombre = nombre.substring(1).trim();
                int r = db.agregarContacto(nombre, numero, "");
                if (r == 1) nuevos++;
                else if (r == 0) repetidos++;
                else malos++;
            }
        }
        return "{\"nuevos\":" + nuevos + ",\"repetidos\":" + repetidos + ",\"malos\":" + malos + "}";
    }

    @JavascriptInterface public String ajuste(String k, String def) { return db.ajuste(k, def); }

    @JavascriptInterface public void guardarAjuste(String k, String v) { db.guardarAjuste(k, v); }

    @JavascriptInterface
    public String textoCompartido() {
        String t = act.textoCompartido;
        act.textoCompartido = null;
        return t == null ? "" : t;
    }

    @JavascriptInterface
    public long contactoInicial() {
        long v = act.contactoInicial;
        act.contactoInicial = -1;
        return v;
    }

    @JavascriptInterface
    public void abrirChat(String numero, String via) {
        act.runOnUiThread(() -> {
            try {
                act.startActivity(Avisos.intentChat(act, numero, via, true));
            } catch (ActivityNotFoundException e) {
                try {
                    act.startActivity(Avisos.intentChat(act, numero, via, false));
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public void probarAviso() {
        Db.Contacto c = new Db.Contacto();
        c.id = 0;
        c.nombre = "Cliente de prueba";
        c.numero = "+5355555555";
        Avisos.avisar(act, c, "WhatsApp", "Hola, me interesa, ¿qué precio tiene?", 1);
    }

    /** Guarda un archivo de texto en la carpeta Descargas. Devuelve "" o el error. */
    @JavascriptInterface
    public String guardarArchivo(String nombre, String contenido) {
        byte[] datos = ("﻿" + contenido).getBytes(StandardCharsets.UTF_8);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = act.getContentResolver();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return "No se pudo crear el archivo";
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) return "No se pudo escribir";
                    os.write(datos);
                }
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) return "No se pudo abrir Descargas";
                try (FileOutputStream os = new FileOutputStream(new File(dir, nombre))) {
                    os.write(datos);
                }
            }
            return "";
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
