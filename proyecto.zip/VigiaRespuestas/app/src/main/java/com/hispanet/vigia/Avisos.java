package com.hispanet.vigia;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/** Aviso al llegar una respuesta: notificación con sonido + vibración (+ voz opcional). */
public final class Avisos {
    private Avisos() {}

    public static final String CANAL = "respuestas_v1";

    public static void crearCanal(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CANAL) != null) return;
        NotificationChannel ch = new NotificationChannel(CANAL, "Respuestas de mis números",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Aviso cuando un número de tu lista te escribe");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 500, 250, 500, 250, 700});
        ch.enableLights(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    public static Intent intentChat(Context ctx, String numero, String via, boolean conPaquete) {
        String d = Numeros.internacional(numero, Db.get(ctx).pais());
        Intent i;
        if ("SMS".equals(via)) {
            i = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:+" + d));
        } else {
            i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + d));
            if (conPaquete) i.setPackage("com.whatsapp");
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return i;
    }

    public static void avisar(Context ctx, Db.Contacto c, String via, String texto, int nuevos) {
        Db db = Db.get(ctx);
        if ("1".equals(db.ajuste("pausado", "0"))) return; // registra, pero sin avisar
        crearCanal(ctx);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        Intent abrir = new Intent(ctx, MainActivity.class)
                .putExtra("contacto", c.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, (int) c.id, abrir, flags);
        PendingIntent pc = PendingIntent.getActivity(ctx, (int) (100000 + c.id),
                intentChat(ctx, c.numero, via, true), flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(ctx, CANAL)
                : new Notification.Builder(ctx);
        String titulo = "Respondió " + c.nombre + (nuevos > 1 ? " (" + nuevos + " mensajes)" : "");
        String cuerpo = via + ": " + (texto == null ? "" : texto);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(titulo)
                .setContentText(cuerpo)
                .setStyle(new Notification.BigTextStyle().bigText(cuerpo))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .addAction(new Notification.Action.Builder((Icon) null, "Abrir chat", pc).build());
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
            b.setDefaults(Notification.DEFAULT_ALL);
        }
        Notification n = b.build();
        if ("1".equals(db.ajuste("insistente", "0"))) n.flags |= Notification.FLAG_INSISTENT;
        try {
            nm.notify((int) (1000 + c.id), n);
        } catch (SecurityException ignored) { }

        if ("1".equals(db.ajuste("voz", "1"))) {
            Voz.decir(ctx, "Respondió " + c.nombre + " por " + ("SMS".equals(via) ? "mensaje" : "WhatsApp"));
        }
    }

    /** Voz del móvil (funciona sin internet si el móvil tiene la voz en español). */
    static final class Voz {
        private static TextToSpeech tts;
        private static boolean listo;
        private static String pendiente;

        static synchronized void decir(Context ctx, String texto) {
            if (tts == null) {
                pendiente = texto;
                tts = new TextToSpeech(ctx.getApplicationContext(), estado -> {
                    synchronized (Voz.class) {
                        if (estado == TextToSpeech.SUCCESS && tts != null) {
                            listo = true;
                            tts.setLanguage(new Locale("es"));
                            if (pendiente != null) {
                                hablar(pendiente);
                                pendiente = null;
                            }
                        }
                    }
                });
                return;
            }
            if (listo) hablar(texto);
            else pendiente = texto;
        }

        private static void hablar(String t) {
            tts.speak(t, TextToSpeech.QUEUE_ADD, null, "v" + System.nanoTime());
        }
    }
}
