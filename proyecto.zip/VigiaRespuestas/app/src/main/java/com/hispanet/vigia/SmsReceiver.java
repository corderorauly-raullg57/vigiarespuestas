package com.hispanet.vigia;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

/** Recibe los SMS normales y registra solo los de números de la lista. */
public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
            SmsMessage[] partes = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (partes == null || partes.length == 0) return;

            String remitente = partes[0].getDisplayOriginatingAddress();
            long ts = partes[0].getTimestampMillis();
            if (ts <= 0) ts = System.currentTimeMillis();
            StringBuilder cuerpo = new StringBuilder();
            for (SmsMessage p : partes) {
                if (p != null && p.getMessageBody() != null) cuerpo.append(p.getMessageBody());
            }

            Db db = Db.get(ctx);
            Db.Contacto c = db.buscarPorNumero(remitente);
            if (c == null) return; // no es de mi lista

            String texto = cuerpo.toString();
            if (db.guardarMensaje(c.id, "SMS", texto, ts)) {
                Avisos.avisar(ctx, c, "SMS", texto, 1);
                MainActivity.refrescar();
            }
        } catch (Throwable t) {
            Db.get(ctx).guardarAjuste("ultimo_error", String.valueOf(t));
        }
    }
}
